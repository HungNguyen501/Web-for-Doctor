-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: webkhambenh
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `patient` (
  `PatientID` int(11) NOT NULL,
  `PatientName` varchar(50) CHARACTER SET utf8 COLLATE utf8_vietnamese_ci NOT NULL,
  `Image` varchar(100) NOT NULL,
  `Birthdate` date NOT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Phone` varchar(13) DEFAULT NULL,
  `Gender` varchar(6) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Disease` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`PatientID`),
  CONSTRAINT `patient_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `account` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,'Ngô Huệ Như','assets/anh/patient1.jpg','2018-10-22','huenhu@gmail.com','0964856324','Nam','đau dạ dày, đầy bụng, chướng hơi '),(2,'Bùi Anh Tú','assets/anh/patient2.jpg','2018-10-22','anhtu@gmail.com','098 456 9887','Nữ','loãng xương, tiểu đường, viêm phế quản'),(3,'Nguyễn Huy Quang','assets/anh/patient3.jpg','2018-10-22','huyquang@gmail.com','0964 567 3452','Nam','thoát vị đĩa đệm, viêm gan C'),(4,'Hồ Quang Hiếu','assets/anh/patient4.jpg','2018-10-22','no-one@gmail.com','0954 467 4387','Nam','viêm gan B, đau dạ dày'),(5,'Hoàng Thảo Nhi','assets/anh/patient5.jpg','2018-10-22','thaonhi@gmail.com','0123456789','Nữ','đái tháo đường, gút'),(6,'Hoàng Hạo Nam','assets/anh/patient6.jpg','1995-11-07','haonam@gmail.com','0123456789','Nam','viêm ruột thừa'),(7,'Đinh Thị Lan Anh','assets/anh/patient7.jpg','1998-12-15','lananh@gmail.com','0123456789','Nữ','viêm phế quản, hen xuyễn'),(8,'Vũ Thị Hương','assets/anh/patient8.jpg','1996-05-07','vuhuong@gmail.com','0123456789','Nữ','thoát vị đĩa đệm, viêm gan C'),(9,'Nguyễn Duy Quốc Anh','assets/anh/patient9.jpg','1997-11-07','quocanh@gmail.com','0987 567 345','Nam','đau thần kinh tọa, đau nửa đầu vai gáy, viêm ruột thừa'),(10,'Nguyễn Kim Hiếu','assets/anh/patient10.jpg','2000-12-15','kimhieu@gmail.com','0945 367 4589','Nam','hen xuyễn, viêm tắc mật');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-23 13:53:49
