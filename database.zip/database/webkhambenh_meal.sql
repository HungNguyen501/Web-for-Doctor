-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: webkhambenh
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `meal`
--

DROP TABLE IF EXISTS `meal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `meal` (
  `MealID` int(11) NOT NULL AUTO_INCREMENT,
  `PatientID` int(11) NOT NULL,
  `MealName` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Image` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Description` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `SendDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`MealID`),
  KEY `PatientID` (`PatientID`),
  CONSTRAINT `meal_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`patientid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meal`
--

LOCK TABLES `meal` WRITE;
/*!40000 ALTER TABLE `meal` DISABLE KEYS */;
INSERT INTO `meal` VALUES (1,1,'Bữa sáng','assets/anh/anh1.png','Thịt lơn luộc, dưa muối, đỗ xào, dưa hấu','2018-12-15 06:22:50'),(2,1,'bữa trưa','assets/anh/anh2.png','\r\n Cá rán, rau muống luộc, thịt xốt cà chua, rau cải cúc xào, dưa chuột tráng miệng','2018-12-15 06:22:59'),(3,1,'bữa tối','assets/anh/anh3.png','Thịt lơn luộc, dưa muối, đỗ xào, dưa hấu','2018-12-15 06:23:08'),(4,1,'bữa tối','assets/anh/anh4.png','\r\nMột bát phở bò, một miếng dưa hấu tráng miệng','2018-12-15 06:23:20'),(5,1,'bữa ăn nhẹ','assets/anh/anh5.png','thịt gà luộc, cá rán, rau lang xào tỏi\r\n','2018-12-15 06:23:33'),(6,2,'bữa trưa','assets/anh/anh6.png','Sườn xào chua ngọt, rau muống xào, Thịt chiên xù, bánh bông lan','2018-12-15 06:23:42'),(7,2,'Bữa chiều','assets/anh/anh7.png','Thịt lơn luộc, dưa muối, đỗ xào, dưa hấu','2018-12-15 06:24:00'),(8,2,'Bữa sáng','assets/anh/anh8.png','Thịt lơn luộc, dưa muối, đỗ xào, dưa hấu','2018-12-15 06:24:17'),(9,3,'Bữa trưa','assets/anh/anh9.png','Thịt lợn luộc, thịt bò xào, tôm luộc hấp xả, dưa lưới','2018-12-15 06:24:27'),(10,3,'bữa tối','assets/anh/anh10.png','Cá rán, rau muống luộc, thịt xốt cà chua, rau cải cúc xào, dưa chuột tráng miệng','2018-12-15 06:24:39'),(11,3,'Bữa sáng','assets/anh/anh11.png','Thịt lợn luộc, thịt bò xào, tôm luộc hấp xả, dưa lưới','2018-12-15 06:24:47'),(12,3,'Bữa sáng','assets/anh/anh12.png','Thịt lơn luộc, dưa muối, đỗ xào, dưa hấu','2018-12-15 06:24:58'),(13,4,'bữa tối','assets/anh/anh13.jpg','Thịt lợn luộc, thịt bò xào, tôm luộc hấp xả, dưa lưới','2018-12-17 14:20:00'),(14,4,'Trưa','assets/anh/anh14.jpg','Cá rán, rau muống luộc, thịt xốt cà chua, rau cải cúc xào, dưa chuột tráng miệng','2018-12-15 07:41:52'),(15,5,'bữa tối','assets/anh/anh15.jpg','Cá rán, rau muống luộc, thịt xốt cà chua, rau cải cúc xào, dưa chuột tráng miệng','2018-12-15 07:43:03'),(16,6,'Bữa trưa','assets/anh/anh16.jpg','Thịt lợn luộc, thịt bò xào, tôm luộc hấp xả, dưa lưới','2018-12-15 07:44:03'),(17,7,'bữa tối','assets/anh/anh17.jpg','Cá rán, rau muống luộc, thịt xốt cà chua, rau cải cúc xào, dưa chuột tráng miệng','2018-12-15 08:05:24'),(18,7,'Bữa sáng','assets/anh/anh18.jpg','gà quay, kim chi muối, thịt xào','2018-12-15 08:05:24'),(19,7,'Bứa tối','assets/anh/anh19.jpg','nem rán, dưa muối, đỗ xào lòng gà, canh cải nấu cá','2018-12-15 08:05:24'),(20,8,'Bữa Sáng','assets/anh/anh20.jpg','gà hầm xả, sữa tiệt trùng','2018-12-15 08:05:24'),(21,4,'Bữa trưa','assets/anh/anh21.jpg','rau sống, tiết canh luộc','2018-12-15 08:05:24'),(22,3,'Bữa trưa','assets/anh/anh22.jpg','bắp cải xào, cá kho, chả lá lốt','2018-12-15 08:05:24'),(23,6,'Bữa tối','assets/anh/anh23.jpg','bắp cải xào, cá kho, chả cá thác lác','2018-12-15 08:05:24'),(24,2,'Bữa sáng','assets/anh/anh24.jpg','bánh mỳ kẹp trứng, sữa tươi, khoai tây chiên','2018-12-15 08:05:24'),(25,10,'Bữa trưa','assets/anh/anh25.jpg','bánh mỳ sốt vang, gà quay 7 món, kim chi muối','2018-12-15 08:05:24'),(26,9,'bữa sáng','assets/anh/anh26.jpg','thịt xông khói, ngô luộc','2018-12-15 08:05:24'),(27,10,'bữa tối','assets/anh/anh27.jpg','gà hầm thuốc bắc, kim chi muối, cá kho','2018-12-15 08:05:24'),(28,6,'bữa trưa','assets/anh/anh28.jpg','thịt nướng, rau cải luộc, cá rán','2018-12-15 08:05:24'),(29,7,'bữa sáng','assets/anh/anh29.jpg','bánh mỳ sốt vang, một cốc nước cam','2018-12-15 08:05:24'),(30,5,'bữa trưa','assets/anh/anh30.jpg','chim 7 món, củ cài luộc','2018-12-15 08:05:24');
/*!40000 ALTER TABLE `meal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-23 13:53:50
